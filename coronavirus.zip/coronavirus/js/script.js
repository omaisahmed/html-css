$.getJSON('https://corona.lmao.ninja/all', function(data) {
        
        var text = `I've Infwected ${data.cases} peoples`
                    
                    
        
        $(".cases").html(text);
    });

    $.getJSON('https://corona.lmao.ninja/all', function(data) {
        
        var text = `And I killed ${data.deaths} of them`
                    
        
        $(".deaths").html(text);
    });